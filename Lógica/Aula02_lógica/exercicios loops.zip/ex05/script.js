let numero1 = parseInt(prompt('Digite o primeiro numero'));
let numero2 = parseInt(prompt('Digite o segundo numero'));

for (let index = numero1; index < numero2; index++) {
   document.write(index + ' ');
}
