for (let index = 1; index < 50; index += 2) {
   document.write(index + ' ');
}
