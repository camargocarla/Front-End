let tabuada = parseInt(prompt('Digite o numero da tabuada'));

for (let i = 1; i <= 10; i++) {
   document.write(tabuada + ' x ' + i + ' = ' + tabuada * i + '<br>');
}
