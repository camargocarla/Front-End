let nota1 = parseFloat(prompt('Digite sua primeira nota'));
let nota2 = parseFloat(prompt('Digite sua segunda nota'));

let media = (nota1 + nota2) / 2;

document.write('Sua média é: ' + media);
