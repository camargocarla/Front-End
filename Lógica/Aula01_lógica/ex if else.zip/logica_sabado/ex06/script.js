let lado1 = parseFloat(prompt('Digite o primeiro lado:'));
let lado2 = parseFloat(prompt('Digite o segundo lado:'));
let lado3 = parseFloat(prompt('Digite o terceiro lado:'));

if (lado1 == lado2 && lado2 == lado3) {
   document.write('O triângulo é equilátero');
} else if (lado1 != lado2 && lado2 != lado3) {
   document.write('O triângulo é escaleno');
} else {
   document.write('O triângulo é isósceles');
}
