let salarioAntigo = parseFloat(prompt('Digite o salário do funcionário:'));
let porcentagemAumento = 0;
let quantidadeAumento = 0;
let novoSalario = 0;

if (salarioAntigo < 280) {
   porcentagemAumento = 20;
   quantidadeAumento = salarioAntigo * 0.2;
   novoSalario = salarioAntigo + quantidadeAumento;
} else if (salarioAntigo < 700) {
   porcentagemAumento = 15;
   quantidadeAumento = salarioAntigo * 0.15;
   novoSalario = salarioAntigo + quantidadeAumento;
} else {
   porcentagemAumento = 10;
   quantidadeAumento = salarioAntigo * 0.1;
   novoSalario = salarioAntigo + quantidadeAumento;
}

document.write('O salário angigo  é: ' + salarioAntigo + '<br>');
document.write('O percentual de aumento é: ' + porcentagemAumento + '<br>');
document.write('O valor do aumento é: ' + quantidadeAumento + '<br>');
document.write('O novo salário é: ' + novoSalario + '<br>');
