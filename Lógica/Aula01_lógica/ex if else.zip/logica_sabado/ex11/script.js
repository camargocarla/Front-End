let numero1 = parseInt(prompt('Digite um número:'));
let numero2 = parseInt(prompt('Digite outro número:'));
let numero3 = parseInt(prompt('Digite mais um número:'));
let numero4 = parseInt(prompt('Digite mais um número:'));
let numero5 = parseInt(prompt('Digite mais um número:'));

if (numero1 % 2 == 0) {
   document.write(numero1 - 5, '<br>');
   document.write(numero1 - 4, '<br>');
   document.write(numero1 - 3, '<br>');
   document.write(numero1 - 2, '<br>');
   document.write(numero1 - 1, '<br>');
   document.write(numero1, '<br>');
   document.write(numero1 + 1, '<br>');
   document.write(numero1 + 2, '<br>');
   document.write(numero1 + 3, '<br>');
   document.write(numero1 + 4, '<br>');
   document.write(numero1 + 5, '<br>');
   document.write(numero1 * 2, '<br>');
}
