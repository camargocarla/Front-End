const peso = parseFloat(prompt('Digite o peso:'));
const altura = parseFloat(prompt('Digite a altura:'));
const sexo = prompt('Digite o sexo (M ou F):');

let imc = 0;

if (sexo == 'M') {
   imc = 72.7 * altura - 58;
} else {
   imc = 62.1 * altura - 44.7;
}

document.write('Seu imc é: ' + imc);
