let numero1 = parseInt(prompt('Digite um número:'));
let numero2 = parseInt(prompt('Digite outro número:'));
let numero3 = parseInt(prompt('Digite mais um número:'));

if (numero1 > numero2 && numero1 > numero3) {
   if (numero2 > numero3) {
      document.write(numero3 + ',' + numero2 + ',' + numero1);
   } else {
      document.write(numero2 + ',' + numero3 + ',' + numero1);
   }
} else if (numero2 > numero1 && numero2 > numero3) {
   if (numero1 > numero3) {
      document.write(numero3 + ',' + numero1 + ',' + numero2);
   } else {
      document.write(numero1 + ',' + numero3 + ',' + numero2);
   }
} else if (numero3 > numero1 && numero3 > numero2) {
   if (numero1 > numero2) {
      document.write(numero2 + ',' + numero1 + ',' + numero3);
   } else {
      document.write(numero1 + ',' + numero2 + ',' + numero3);
   }
}
