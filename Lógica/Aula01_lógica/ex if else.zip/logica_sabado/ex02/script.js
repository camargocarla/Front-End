let nota1 = parseFloat(prompt('Digite sua primeira nota'));
let nota2 = parseFloat(prompt('Digite sua segunda nota'));
let nota3 = parseFloat(prompt('Digite sua terceira nota'));

let media = (nota1 + nota2 + nota3) / 3;

if (media < 7) {
   document.write('Sua média é: ' + media + ' Você foi reprovado.');
} else if (media == 7) {
   document.write('Sua média é: ' + media);
} else {
   document.write('Sua média é: ' + media + ' Você foi aprovado.');
}
