let numero1 = parseFloat(prompt('Digite o primeiro número:'));
let numero2 = parseFloat(prompt('Digite o segundo número:'));
let numero3 = parseFloat(prompt('Digite o terceiro número:'));

if (numero1 < numero2 && numero1 < numero3) {
   document.write('O menor número é: ' + numero1);
} else if (numero2 < numero1 && numero2 < numero3) {
   document.write('O menor número é: ' + numero2);
} else if (numero3 < numero1 && numero3 < numero2) {
   document.write('O menor número é: ' + numero3);
} else {
   document.write('Os números são iguais');
}
