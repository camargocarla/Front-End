let produto = prompt(
   `Escolha seu produto \n 1 - Pizza R$ 12,00\n 
   2 - Pão de Queijo R$ 4,00\n 
   3 - Macarrão R$ 8,00\n 
   4 - Pastel R$ 4,50`
);

let valorPagamento = parseFloat(prompt('Digite o valor do pagamento'));

if (produto == '1') {
   if (valorPagamento < 12) {
      document.write('Valor insuficiente');
   } else {
      let troco = valorPagamento - 12;
      document.write('Troco: ' + troco);
   }
} else if (produto == '2') {
   if (valorPagamento < 4) {
      document.write('Valor insuficiente');
   } else {
      let troco = valorPagamento - 4;
      document.write('Troco: ' + troco);
   }
} else if (produto == '3') {
   if (valorPagamento < 8) {
      document.write('Valor insuficiente');
   } else {
      let troco = valorPagamento - 8;
      document.write('Troco: ' + troco);
   }
} else if (produto == '4') {
   if (valorPagamento < 4.5) {
      document.write('Valor insuficiente');
   } else {
      let troco = valorPagamento - 4.5;
      document.write('Troco: ' + troco);
   }
}
