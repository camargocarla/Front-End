let numero1 = parseFloat(prompt('Digite o primeiro número:'));
let numero2 = parseFloat(prompt('Digite o segundo número:'));
let operacao = prompt('Digite a operação desejada (+, -, *, /) ');

if (operacao == '+') {
   document.write('O resultado da soma é: ' + (numero1 + numero2));
} else if (operacao == '-') {
   document.write('O resultado da subtração é: ' + (numero1 - numero2));
} else if (operacao == '*') {
   document.write('O resultado da multiplicação é: ' + numero1 * numero2);
} else if (operacao == '/') {
   document.write('O resultado da divisão é: ' + numero1 / numero2);
} else {
   document.write('Operação inválida!');
}
