
let entrar = document.getElementById('entrar');

let user = []

function cadastrar(){
    let nome = document.getElementById('nome');
    let cpf = document.getElementById('cpf');
    let email = document.getElementById('email');
    let telefone = document.getElementById('telefone');
    let senha = document.getElementById('senha');

    if(localStorage.getItem('vetor') != undefined){
        user = JSON.parse(localStorage.getItem('vetor'))
    }
    
    user.push({'email':email, 'senha':senha})
    localStorage.setItem('vetor', JSON.stringify(user))
    
}

entrar.addEventListener('click', entrar);

let buttom = document.getElementById('entrar')

function aparecaPainel(){
    window.location.assign('/Projeto_Banco/pagInicial.html')
}

localStorage.setItem('cpf', 'email');

function validarCadastro() {
    const cpf = document.getElementById('cpf').value;
    const email = document.getElementById('email').value;
    const usuariosCadastrados = JSON.parse(localStorage.getItem('usuariosCadastrados')) || [];
    const usuarioExistente = usuariosCadastrados.find(usuario => usuario.cpf === cpf || usuario.email === email);

  if (usuarioExistente) {
    alert('CPF ou E-mail já cadastrados.');
  } else {
    alert('CPF e E-mail ainda não foram cadastrados.');
  }
}
